package com.Lab7Assignment.elibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
