package com.Lab7Assignment.eregister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EregisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(EregisterApplication.class, args);
	}

}
