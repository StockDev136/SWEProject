# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.0.7/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.0.7/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/4.0.7/reference/web/servlet.html)
* [Thymeleaf](https://docs.spring.io/spring-boot/4.0.7/reference/web/servlet.html#web.servlet.spring-mvc.template-engines)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Handling Form Submission](https://spring.io/guides/gs/handling-form-submission/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

### Enabling DevTools + LiveReload

This project already includes `spring-boot-devtools` as a dependency. To get the full hot-reload workflow while developing:

1. In IntelliJ IDEA: File -> Settings -> Build, Execution, Deployment -> Compiler -> check "Build project automatically".
2. Press Shift+Ctrl+A, search "Registry", and enable `compiler.automake.allow.when.app.running` (not needed on IntelliJ IDEA 2019.1.x or newer - already on by default).
3. Install the "LiveReload" browser extension (Chrome Web Store, or https://addons.mozilla.org/de/firefox/addon/livereload-web-extension/ for Firefox).
4. Start the app, open it in the browser, and click the LiveReload extension icon to enable it.
5. Static content (HTML/CSS/JS) refreshes automatically on save; Java and Thymeleaf template changes restart the Spring context and push the update to the browser - no manual refresh needed.
